mymixedtypelist = [45,25, "rohith","50"]
for item in mymixedtypelist :
    print("{} is of the data type {}" .format(item,type(item)))