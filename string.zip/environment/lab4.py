myfruitlist = ("apple", "banana", "cherry")
print(myfruitlist)
print(type(myfruitlist))

awsrestart = {
    "anmol" : "trainer",
    "shasahnk" :"Student",
    "Ranga":"Student"
}

print(awsrestart)
print(type(awsrestart))
print(awsrestart["anmol"])
print(awsrestart["shashank"])
