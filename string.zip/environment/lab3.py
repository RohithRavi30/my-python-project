firstString = "water"
secondString = "fall"
thirdString = firstString+secondString
print(thirdString)

name = input("what is your name? ")
color = input("what is your favourite color?")
animal=input("what is your favourite animal?")
print("{} {} {}!".format(name,color,animal))