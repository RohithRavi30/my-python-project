a=3
print(a)
print(type(a))
print(str(a) + " is of the data type " + str(type(a)) + str(int(2023)))